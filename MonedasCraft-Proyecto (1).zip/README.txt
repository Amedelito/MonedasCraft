MonedasCraft para PaperMC 1.21.1 / Java 21

COMPILAR: abre esta carpeta en IntelliJ IDEA como proyecto Gradle y ejecuta Tasks > build. El JAR sale en build/libs/.
INSTALAR: copia el JAR a plugins/ y reinicia Paper.
COMANDOS: /monedas moneda [jugador] [cantidad] ; /monedas maquina [jugador] [cantidad]
USO: coloca la máquina (queda como barril funcional) y haz clic derecho con un lingote de oro para recibir 9 monedas.
PERMISOS: monedascraft.admin (OP por defecto), monedascraft.use (true por defecto).

RESOURCE PACK: instala MonedasCraft-ResourcePack.zip desde Opciones > Paquetes de recursos. Es para Minecraft Java 1.21.1.
NOTA: el modelo 3D de la máquina aparece como objeto en mano/inventario; al colocarla, el bloque funcional es un barril vanilla con etiqueta interna, para no reemplazar la apariencia de todos los barriles del juego.
