package me.amets.monedascraft;

import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.block.Block;
import org.bukkit.block.TileState;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.inventory.EquipmentSlot;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.plugin.java.JavaPlugin;

public final class MonedasCraft extends JavaPlugin implements Listener {
    private NamespacedKey typeKey, machineKey;
    @Override public void onEnable() {
        typeKey = new NamespacedKey(this, "tipo");
        machineKey = new NamespacedKey(this, "maquina_monedas");
        Bukkit.getPluginManager().registerEvents(this, this);
        getLogger().info("MonedasCraft activado.");
    }
    private ItemStack item(Material material, int model, String name, String type) {
        ItemStack stack = new ItemStack(material);
        ItemMeta meta = stack.getItemMeta();
        meta.setDisplayName(ChatColor.GOLD + name);
        meta.setCustomModelData(model);
        meta.getPersistentDataContainer().set(typeKey, PersistentDataType.STRING, type);
        if (type.equals("moneda")) meta.setLore(java.util.List.of(ChatColor.GRAY + "Moneda física de MonedasCraft", ChatColor.YELLOW + "Se puede canjear en una máquina."));
        else meta.setLore(java.util.List.of(ChatColor.GRAY + "Colócala para crear una máquina", ChatColor.GREEN + "Clic derecho para canjear oro."));
        stack.setItemMeta(meta); return stack;
    }
    private ItemStack stack(ItemStack item, int amount) { item.setAmount(amount); return item; }
    private boolean is(ItemStack s, String type) {
        if (s == null || !s.hasItemMeta()) return false;
        return type.equals(s.getItemMeta().getPersistentDataContainer().get(typeKey, PersistentDataType.STRING));
    }
    @Override public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
        if (!cmd.getName().equalsIgnoreCase("monedas")) return false;
        if (!(sender instanceof Player p) && (args.length == 0 || !args[0].equalsIgnoreCase("moneda"))) { sender.sendMessage("Este comando requiere un jugador."); return true; }
        if (!sender.hasPermission("monedascraft.admin")) { sender.sendMessage(ChatColor.RED + "No tienes permiso."); return true; }
        Player p = sender instanceof Player ? (Player)sender : null;
        if (args.length == 0 || args[0].equalsIgnoreCase("ayuda")) {
            sender.sendMessage(ChatColor.GOLD + "/monedas moneda [jugador] [cantidad]" );
            sender.sendMessage(ChatColor.GOLD + "/monedas maquina [jugador] [cantidad]"); return true;
        }
        String type=args[0].toLowerCase();
        Player target=p; int amount=1;
        if (args.length>=2) { Player found=Bukkit.getPlayerExact(args[1]); if(found!=null) target=found; else if(p!=null) { try { amount=Integer.parseInt(args[1]); } catch(NumberFormatException ignored) {} } }
        if(args.length>=3) { try { amount=Integer.parseInt(args[2]); } catch(NumberFormatException ex) { sender.sendMessage(ChatColor.RED+"Cantidad no válida."); return true; } }
        if(target==null) { sender.sendMessage("Indica un jugador conectado."); return true; }
        amount=Math.max(1,Math.min(64,amount));
        if(type.equals("moneda")) target.getInventory().addItem(stack(item(Material.GOLD_NUGGET,1001,"Moneda AURUM","moneda"), amount));
        else if(type.equals("maquina")) target.getInventory().addItem(stack(item(Material.IRON_BLOCK,1002,"Máquina de Monedas","maquina"), amount));
        else { sender.sendMessage(ChatColor.RED+"Uso: /monedas moneda|maquina [jugador] [cantidad]"); return true; }
        sender.sendMessage(ChatColor.GREEN+"Objeto entregado a "+target.getName()+"."); return true;
    }
    @EventHandler public void onPlace(PlayerInteractEvent e) {
        if (e.getHand()!=EquipmentSlot.HAND || e.getAction()!=Action.RIGHT_CLICK_BLOCK) return;
        Player p=e.getPlayer(); ItemStack hand=e.getItem(); Block clicked=e.getClickedBlock();
        if (clicked==null || !is(hand,"maquina")) return;
        if (!p.hasPermission("monedascraft.use")) { p.sendMessage(ChatColor.RED+"No tienes permiso para usar máquinas."); return; }
        Block place=clicked.getRelative(e.getBlockFace());
        if(!place.getType().isAir()) { p.sendMessage(ChatColor.RED+"Necesitas espacio libre para colocar la máquina."); return; }
        place.setType(Material.BARREL);
        if(place.getState() instanceof TileState state) { state.getPersistentDataContainer().set(machineKey,PersistentDataType.BYTE,(byte)1); state.update(); }
        if(hand.getAmount()==1) p.getInventory().setItemInMainHand(null); else hand.setAmount(hand.getAmount()-1);
        p.sendMessage(ChatColor.GREEN+"Máquina colocada. Clic derecho con un lingote de oro para obtener monedas."); e.setCancelled(true);
    }
    @EventHandler public void onUse(PlayerInteractEvent e) {
        if(e.getHand()!=EquipmentSlot.HAND || e.getAction()!=Action.RIGHT_CLICK_BLOCK || e.getClickedBlock()==null) return;
        Block b=e.getClickedBlock(); if(!(b.getState() instanceof TileState state)) return;
        if(!state.getPersistentDataContainer().has(machineKey,PersistentDataType.BYTE)) return;
        e.setCancelled(true); Player p=e.getPlayer(); ItemStack hand=p.getInventory().getItemInMainHand();
        if(hand.getType()!=Material.GOLD_INGOT || hand.getAmount()<1) { p.sendMessage(ChatColor.YELLOW+"Sostén un lingote de oro para canjearlo por 9 monedas."); return; }
        hand.setAmount(hand.getAmount()-1);
        ItemStack coins=stack(item(Material.GOLD_NUGGET,1001,"Moneda AURUM","moneda"), 9);
        java.util.Map<Integer,ItemStack> overflow=p.getInventory().addItem(coins);
        overflow.values().forEach(it->p.getWorld().dropItemNaturally(p.getLocation(),it));
        p.sendMessage(ChatColor.GOLD+"Canje realizado: +9 monedas AURUM.");
    }
}
